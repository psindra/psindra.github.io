// chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {	
	// if(changeInfo.status == 'complete' && tab.url.includes('youtube') && tab.url.includes('watch?v=')) {
		// chrome.scripting.executeScript({
			// target: {tabId: tabId, allFrames: true},
			// files: ['/hd.js']
		// });
	// }	
// });